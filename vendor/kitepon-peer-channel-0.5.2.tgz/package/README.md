# peer-channel TypeScript part (`@kitepon/peer-channel`)

Contract `pc/1` (docs/contract.md, draft 0.4.8; signaling wire: docs/signaling.md).
- Milestone 1, `src/*.ts`: byte encodings (3.1), key ids and fingerprints, signed snapshots (4.1), holder registry rules (4.2-4.4), HPKE signaling envelopes (6.4), frames, chunks, and the answer/result checks (8.1-8.3, row order of 0.4.7).
- Milestone 2, `src/server/`: the server part (6): signaling socket, waits, join, envelope relay within one K, verify pairs (5 min), content-free `wake` (product-supplied), TURN credentials, and the registry mirror (4.5) behind `MirrorStore` (memory, or SQLite through `node:sqlite` with `secure_delete` on). The pool table is `MIRROR_POOLS` / `MIRROR_CAPS` in `src/server/mirror.ts`.
- Milestone 2, `src/connector/connector.ts`: the connector endpoint (9): keys, outbox and tombstones in a 0600 state file, listen gate, mirror read before an offer, WebRTC data channel `peer-channel/1` through node-datachannel, `hello` with DTLS fingerprints, request/amend/cancel/ack/answer/result, answer acceptance (8.3), close-out and tombstones. It executes nothing.
- ICE on the connector: one libjuice socket on the wildcard address, so every local address (IPv4 and IPv6) is a host candidate and same-host pairs work. Known limit: libjuice cannot choose a reply's source address, so on a host with two addresses on one LAN some pairs see non-symmetric replies; a relay (TURN) path is not affected. The connector also offers each IPv4 UDP host port on 127.0.0.1 (the "loopback twin", once per port): libjuice gathers no loopback candidate, but its wildcard socket receives on 127.0.0.1 and answers from it, so a device on the same host can pair over loopback where it may not reach the host's LAN addresses (macOS Local Network privacy drops an ungranted app's datagrams to them). Remote candidates that arrive before the peer connection exists are queued; mDNS `.local` names are resolved by the system resolver or skipped.
- Milestone 2, `src/connector/pairing.ts` (`@kitepon/peer-channel/pairing`, no WebRTC): the connector's side of the 5.4 key binding as the starter over `verify.*` (contract 0.5.1 rows 1-6): `startPairingBinding(keys)` gives the `PC1PAIR` QR text and the typed code to show beside the product's pairing code; `complete()` after the product's claim runs pc1-join → pc1-admit and returns the admitted snapshot for `Connector`'s `admission`. The connector can open its verify ids only after the claim (it has no connection token before), so an approver that scanned at once gets `unknown_verify` and retries `verify.join` until joined (5 minutes); the `./testing` device's `approveConnector` does so.
- Blobs and `hold` (contract 0.5.2, `src/blob.ts`): request blobs are given to `Connector.request/amend` and kept as 0600 files beside the outbox until the request is forgotten; they follow each request frame. Answer blobs are assembled and SHA-256 checked before the answer is accepted and handed to `onAnswer` with it. A device `hold` is checked like an answer and handed to `onHold`. Limits of 8.7; 16 KiB of data per blob message; 60 s for a named blob.
- Not built: key storage in the OS store (the product hands the keys in), frame padding to 1 KiB steps (12), the login-billing handoff payloads (5.2, a stub until Mint's reading-3 design), a browser client.

`authenticate(request)` returns `{ k, kind: "device" | "connector", endpoint_ref, pass_kind? }` (6.1): for devices `endpoint_ref` is the login-billing pass id (`Checked.pid`) and `pass_kind` its `Checked.kind`; for connectors it is the product's connection id. Return `null` for no identity (401), or `{ refused: <library code> }` for a refused pass (403).

Wire the library's `onPassEnded(callback)` (login-billing 1.19, server part 0.8.1) to the server part's `onPassEnded(event)`: it frees the mirror slots of an ended login at once (contract 4.5, 0.4.10); the 90-day freeing stays the rule when a signal is missed.

## Local signaling server for the Swift and Kotlin parts

```
cd ts && npm ci && npm run dev:signaling
```

Starts the server part on `http://127.0.0.1:8787` (`ws://127.0.0.1:8787/pc/v1/signal`) with a fake `authenticate` and a `wake` that prints `wake alert=1|0` (never K). Tokens: `Authorization: Bearer dev.device.<K>.<pass id>.store|signed|handoff` or `Bearer dev.connector.<K>.<connection id>`. Environment: `PC_DEV_PORT` (default 8787), `PC_DEV_MIRROR_DB` (SQLite file for the mirror; memory when unset), `PC_DEV_TURN_URLS` (comma-separated `turn:`/`stun:` URLs; none by default, loopback needs none). Message shapes and error codes: docs/signaling.md.

`npm test` builds and runs every file under `../vectors/` plus the unit tests (mirror rules, signaling relay and TTLs) and an end-to-end test: server part + connector + a TS test device over a loopback data channel, request → answer → result, a stale version with `current`, an unknown device refused, and a leak check of what the server wrote; a vector file without a TS runner fails. `npm run vectors` regenerates `vectors/pc1-ts.json`.

WebRTC and WebSocket pins (exact versions, integrity in `package-lock.json`):
- `node-datachannel@0.33.6` (libdatachannel; prebuilt per platform as `@node-datachannel/<platform>@0.33.6`) sha512-n7RzImzysrOVFx/lXfkQQ4fL0wsuPXBFc8KM69V29iyIor/UX7Ej+edzNGWJm+3mApZG9nkLi7FsGAZhQCDA4w==
- `ws@8.23.0` sha512-wCkmX8QMOrKjgO8HW2WyDbTSGeqkocxgDzS9iR79rEAexty6/2qzilx3Ag8Tqf9ykop3irLKle0MtVn5qjVnoQ==

HPKE pin (contract 3.1 conditions): `@hpke/core` 1.10.1 (hpke-js, WebCrypto core; mode_base, 0x0010/0x0001/0x0002 only) and its `@hpke/common` 1.13.0, exact versions with the integrity hashes in `package-lock.json`:
- `@hpke/core@1.10.1` sha512-VZOk0rHC4vPsbW/fIRz7Q2IviSl0+9dRhP9yi/PmkKVKjj4vZDs1ufkN47twBFLZmiw37YFtTqBrxKAI7dlOrg==
- `@hpke/common@1.13.0` sha512-PqaJR89RWJQmt/WOGuBLrcrtXtEMbWu91XIbxDjKDTDgKvqvhlxOzQ9BAf9a0Q+yqqbTtQ0pK6KUyVi2WMehbA==

A new hpke-js release is reviewed before this pin moves; record the review here.

## Packaging for products

`npm pack` (in `ts/`) builds and writes `kitepon-peer-channel-<version>.tgz` with `dist/src` only (no tests). A product vendors that file and pins it by its sha256, the way Approval Box consumes login-billing; there is no git dependency and no registry publish (`private`). A product that uses only the server part imports `@kitepon/peer-channel/server`. npm ignores `overrides` inside a dependency, so a product that wants the reviewed `@hpke/common` 1.13.0 pins it in its own `overrides`.
